<?php
require('dbcon.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8 form-container">
            <h1>Products</h1>
            <hr>
            <table class="table">
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
                <?php
                $sql = "SELECT * FROM `products` ORDER BY pid DESC";
                $result = mysqli_query($con, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td><img src='".$row['image']."' class='product-image'></td>";
                        echo "<td>".$row['title']."</td>";
                        echo "<td>".$row['price']."</td>";
                        echo "<td><a href='checkout.php?product_id=".$row['pid']."' class='btn btn-primary'>Buy Now</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No products found.</td></tr>";
                }
                ?>
            </table>
        </div>
        <div class="col-sm-3"></div>
    </div>
</div>
</body>
</html>
