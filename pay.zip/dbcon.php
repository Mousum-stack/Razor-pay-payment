<?php
session_start();
$hname = 'localhost';
$uname = 'root';
$pass = '';
$db = 'pay';

$con = mysqli_connect($hname,$uname,$pass,$db);

?>