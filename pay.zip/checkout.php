<?php
require('dbcon.php');
$pid = $_GET['product_id'];

// SQL query to fetch product details by ID
$sql = "SELECT * FROM `products` WHERE pid = $pid";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $title = $row['title'];
    $price = $row['price'];
    $image = $row['image'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-sm-8 form-container">
            <h1>Checkout</h1>
            <hr>
            <?php
                if(isset($_POST['sumbit_form']))
                {
                    $_SESSION['fname']=$_POST['fname'];
                    $_SESSION['lname']=$_POST['lname'];
                    $_SESSION['email']=$_POST['email'];
                    $_SESSION['mobile']=$_POST['mobile'];
                    $_SESSION['address']=$_POST['address'];
                    $_SESSION['note']=$_POST['note'];
                    $_SESSION['pid']=$pid;
                    if($_POST['email']!='')
                    {
                        header("Location:pay.php");
                    }
                }
            ?>
            <div class="row">
                <div class="col-8">
                    <form action="" method="POST">  
                        <div class="mb-3">
                            <label class="lable">First Name</label>
                            <input type="text" class="form-control" name="fname" required>
                        </div>
                        <div class="mb-3">
                            <label class="lable">Last Name</label>
                            <input type="text" class="form-control" name="lname" required>
                        </div>
                        <div class="mb-3">
                            <label class="lable">Email</label>
                            <input type="text" class="form-control" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label class="lable">Mobile</label>
                            <input type="text" class="form-control" name="mobile" required>
                        </div>
                        <div class="mb-3">
                            <label class="lable">Address</label>
                            <textarea type="text" class="form-control" name="address" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="lable">Note</label>
                            <textarea type="text" class="form-control" name="note" required></textarea>
                        </div>
                        
                </div>
                <div class="col-sm-4 text-center">
                    <img src="<?php echo $image; ?>" class="product-image">
                    <h4><?php echo $title; ?></h4>
                    <h5>Price: <?php echo $price; ?>  INR</h5>
                    <br>
                    <button type="submit" name="sumbit_form" class="btn btn-primary">Place Order</button>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

<?php
} else {
    echo "No product found with ID: $pid";
}
?>
