<?php
require('razorpay-php/Razorpay.php'); // Include the Razorpay PHP library
require('dbcon.php'); // Include the database connection file

session_start(); // Start the session

$pid = $_SESSION['pid']; // Get the product ID from the session

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-sm-8 form-container">
            <h1>Payment</h1>
            <hr>
            <?php
            require("gateway-config.php"); // Include the Razorpay configuration file
            use Razorpay\Api\Api; // Import the Razorpay API class

            $api = new Api($keyId, $keySecret); // Create a new instance of the Razorpay API with your API key and secret
            $firstname = $_SESSION['fname']; // Get the first name from the session
            $lastname = $_SESSION['lname']; // Get the last name from the session
            $email = $_SESSION['email']; // Get the email from the session
            $mobile = $_SESSION['mobile']; // Get the mobile number from the session
            $address = $_SESSION['address']; // Get the address from the session
            $note = $_SESSION['note']; // Get the note from the session
            $sql = "SELECT * FROM `products` WHERE pid = $pid"; // Retrieve the product details from the database using the product ID
            $result = mysqli_query($con, $sql); // Execute the query

            if ($result && mysqli_num_rows($result) > 0) { // If the query was successful and there is at least one row returned
                $row = mysqli_fetch_assoc($result); // Fetch the row data
                $title = $row['title']; // Get the product title from the row
                $price = $row['price']; // Get the product price from the row
                $_SESSION['price'] = $price; // Store the price in the session
                $image = $row['image']; // Get the product image URL from the row
                $title = $row['title']; // Get the product title from the row
                $webtitle = 'Mousum'; // Set the website title
                $displayCurrency = 'INR'; // Set the currency to INR (Indian Rupees)
                $orderData = [
                    'receipt'         => 3456, // Generate a unique receipt number for each order
                    'amount'          => $price * 100, // Convert the price to paise (Indian currency is in paise)
                    'currency'        => 'INR', // Set the currency to INR
                    'payment_capture' => 1 // Enable auto-capture of payment
                ];
                $razorpayOrder = $api->order->create($orderData); // Create a new Razorpay order with the order data

                $razorpayOrderId = $razorpayOrder['id']; // Get the ID of the created order

                $_SESSION['razorpay_order_id'] = $razorpayOrderId; // Store the order ID in the session

                $displayAmount = $amount = $orderData['amount']; // Set the display amount and actual amount to the order amount

                if ($displayCurrency !== 'INR') { // If the display currency is not INR
                    $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR"; // URL to fetch the exchange rate from INR to the display currency
                    $exchange = json_decode(file_get_contents($url), true); // Fetch the exchange rate data and decode the JSON response

                    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100; // Convert the amount to the display currency
                }
                $data = [
                    "key"               => $keyId, // Razorpay API key
                    "amount"            => $amount, // Amount in paise
                    "name"              => $webtitle, // Website title
                    "description"       => $title, // Product title
                    "image"             => "https://s29.postimg.org/r6dj1g85z/daft_punk.jpg", // URL of the product image
                    "prefill"           => [
                        "name"              => $firstname . ' ' . $lastname, // Payer's full name
                        "email"             => $email, // Payer's email
                        "contact"           => $mobile, // Payer's mobile number
                    ],
                    "notes"             => [
                        "address"           => $address, // Payer's address
                        "merchant_order_id" => "12312321", // Custom merchant order ID
                    ],
                    "theme"             => [
                        "color"             => "#F37254" // Theme color for the Razorpay checkout form
                    ],
                    "order_id"          => $razorpayOrderId, // Razorpay order ID
                ];
                if ($displayCurrency !== 'INR') { // If the display currency is not INR
                    $data['display_currency']  = $displayCurrency; // Set the display currency
                    $data['display_amount']    = $displayAmount; // Set the display amount
                }

                $json = json_encode($data); // Convert the data array to JSON
            } else {
                echo "No product found with ID: $pid"; // Display an error message if no product is found with the given ID
                exit();
            }
            ?>
            <div class="row">
                <div class="col-8">
                    <h4>(Payer Details)</h4>
                    <div class="mb-3">
                        <label class="label">First Name</label>
                        <?php echo $firstname; ?>
                    </div>
                    <div class="mb-3">
                        <label class="label">Last Name</label>
                        <?php echo $lastname; ?>
                    </div>
                    <div class="mb-3">
                        <label class="label">Email</label>
                        <?php echo $email; ?>
                    </div>
                    <div class="mb-3">
                        <label class="label">Mobile</label>
                        <?php echo $mobile; ?>
                    </div>
                    <div class="mb-3">
                        <label class="label">Address</label>
                        <?php echo $address; ?>
                    </div>
                    <div class="mb-3">
                        <label class="label">Note</label>
                        <?php echo $note; ?>
                    </div>
                </div>
                <div class="col-sm-4 text-center">
                    <img src="<?php echo $image; ?>" class="product-image">
                    <h4><?php echo $title; ?></h4>
                    <h5>Price: <?php echo $price; ?> INR</h5>
                    <br>
                    <center>
                        <form action="verify.php" method="POST">
                            <script
                                src="https://checkout.razorpay.com/v1/checkout.js"
                                data-key="<?php echo $data['key']?>"
                                data-amount="<?php echo $data['amount']?>"
                                data-currency="INR"
                                data-name="<?php echo $data['name']?>"
                                data-image="<?php echo $data['image']?>"
                                data-description="<?php echo $data['description']?>"
                                data-prefill.name="<?php echo $data['prefill']['name']?>"
                                data-prefill.email="<?php echo $data['prefill']['email']?>"
                                data-prefill.contact="<?php echo $data['prefill']['contact']?>"
                                data-notes.shopping_order_id="<?php echo $pid; ?>"
                                data-order_id="<?php echo $data['order_id']?>"
                                <?php if ($displayCurrency !== 'INR') { ?> data-display_amount="<?php echo $data['display_amount']?>" <?php } ?>
                                <?php if ($displayCurrency !== 'INR') { ?> data-display_currency="<?php echo $data['display_currency']?>" <?php } ?>
                            >
                            </script>
                            <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
                            <input type="hidden" name="shopping_order_id" value="<?php echo $pid; ?>">
                        </form>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
