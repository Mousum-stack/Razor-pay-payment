<?php

$keyId= 'rzp_test_VYcY2KWt59UGQv';
$keySecret= 'y03TUx7MlqfPbhteX9kk3Sa9';
?>