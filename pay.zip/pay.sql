-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 12, 2023 at 06:04 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pay`
--

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payid` int(11) NOT NULL,
  `firstname` varchar(150) DEFAULT NULL,
  `lastname` varchar(400) DEFAULT NULL,
  `amount` varchar(20) DEFAULT NULL,
  `txnid` varchar(100) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `payer_email` varchar(100) DEFAULT NULL,
  `currency` varchar(100) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payid`, `firstname`, `lastname`, `amount`, `txnid`, `pid`, `payer_email`, `currency`, `mobile`, `address`, `note`, `payment_date`, `status`) VALUES
(1, 'John', 'gogoi', '123', 'pay_LsO0XWhBK3WDA3', 6, 'mousumgogoi392@gmail.com', 'INR', '7086907503', 'South Amolapatty', '123qwe', '2023-05-21 22:54:49', 'success'),
(2, 'John', 'gogoi', '123', 'pay_LsP4NGe6N50chw', 6, 'mousumgogoi392@gmail.com', 'INR', '7086907503', 'South Amolapatty', '123qwe', '2023-05-21 23:28:03', 'success'),
(3, 'John', 'gogoi', '123', 'pay_LsPQwIdzCqtddx', 6, 'mousumgogoi392@gmail.com', 'INR', '7086907503', 'South Amolapatty', '123qwe', '2023-05-21 23:49:25', 'success'),
(4, 'John', 'gogoi', '123', 'pay_Lt9OzOAtrQv7iM', 6, 'mousumgogoi392@gmail.com', 'INR', '7086907503', 'South Amolapatty', '123qwe', '2023-05-23 20:47:29', 'success'),
(5, 'John', 'gogoi', '123', 'pay_Lt9RREcHtyITTQ', 6, 'mousumgogoi392@gmail.com', 'INR', '7086907503', 'South Amolapatty', '123qwe', '2023-05-23 20:49:45', 'success'),
(6, 'John', 'gogoi', '123', 'pay_Lt9VnEF2Uciv0f', 6, 'mousumgogoi392@gmail.com', 'INR', '7086907503', 'South Amolapatty', '123qwe', '2023-05-23 20:53:53', 'success'),
(7, 'Mousum', 'Gogoi', '123', 'pay_LtxSq7WmiXnHl8', 6, 'mousumgogoi392@gmail.com', 'INR', '7086907503', 'South Amolapatty', 'a,sn d', '2023-05-25 21:45:47', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `price` varchar(20) NOT NULL,
  `image` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `title`, `price`, `image`) VALUES
(1, 'name', '123', 'uploads/3.jpeg'),
(2, 'name', '123', 'uploads/3.jpeg'),
(3, 'name', '123', 'uploads/3.jpeg'),
(4, 'zeta', '123', 'uploads/1531552.webp'),
(5, 'raj', '324', 'uploads/7I3c.gif'),
(6, 'mousum', '123', 'uploads/80857660_2963433253700837_2599198702983708672_n.jpg'),
(7, 'name', '999', 'uploads/406ED84B-EF26-4D5E-90B2-49B43BF3F2AA.JPG'),
(8, 'n', '123', 'uploads/7I3c.gif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
