<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require('razorpay-php/Razorpay.php');
require('dbcon.php');
require("gateway-config.php");

session_start();

$pid = $_SESSION['pid'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-sm-8 form-container">
            <h1>Payment Status</h1>
            <hr>

            <div class="row">
                <div class="col-8">
                <?php 
                    use Razorpay\Api\Api;
                    use Razorpay\Api\Errors\SignatureVerificationError;

                    $success = true;
                    $error = "Payment Failed";
                    require("gateway-config.php");

                    if (empty($_POST['razorpay_payment_id']) === false)
                    {
                        $api = new Api($keyId, $keySecret);

                        try
                        {
                            // Please note that the razorpay order ID must
                            // come from a trusted source (session here, but
                            // could be database or something else)
                            $attributes = array(
                                'razorpay_order_id' => $_SESSION['razorpay_order_id'],
                                'razorpay_payment_id' => $_POST['razorpay_payment_id'],
                                'razorpay_signature' => $_POST['razorpay_signature']
                            );

                            $api->utility->verifyPaymentSignature($attributes);
                        }
                        catch(SignatureVerificationError $e)
                        {
                            $success = false;
                            $error = 'Razorpay Error : ' . $e->getMessage();
                        }
                    }

                    if ($success === true)
                    {
                        $firstname = $_SESSION['fname'];
                        $lastname = $_SESSION['lname'];
                        $email = $_SESSION['email'];
                        $mobile = $_SESSION['mobile'];
                        $address = $_SESSION['address'];
                        $note = $_SESSION['note'];

                        $posted_hash = $_SESSION['razorpay_order_id'];

                        if (isset($_POST['razorpay_payment_id']))
                        {
                            $txnid = $_POST['razorpay_payment_id'];
                            $amount = $_SESSION['price'];
                            $status = 'success';
                            $eid = $_POST['shopping_order_id'];
                            $subject = 'Your payment has been successful.';
                            $key_value = 'okpmt';
                            $currency = 'INR';
                            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
                            $payment_date = $date->format('Y-m-d H:i:s');

                            $sql = "SELECT COUNT(*) FROM payments WHERE txnid = '$txnid'";
                            $result = mysqli_query($con, $sql);

                            if ($result)
                            {
                                $row = mysqli_fetch_row($result);
                                $count = $row[0];

                                if ($count <= 0) {
                                    // Payment with the given txnid does not exist
                                    // Insert the payment details into the payments table
                                    $sql = "INSERT INTO payments (firstname, lastname, amount, txnid, pid, payer_email, currency, mobile, address, note, payment_date, status) 
                                            VALUES ('$firstname', '$lastname', '$amount', '$txnid', '$pid', '$email', '$currency', '$mobile', '$address', '$note', '$payment_date', '$status')";
                                
                                    if (mysqli_query($con, $sql)) {
                                        echo '<h2>'.$subject.'</h2> <hr>';
                                        // Handle the appropriate logic here
                                        
                                
                                        $result = mysqli_query($con, "SELECT * FROM `payments` WHERE txnid = '$txnid'");
                                
                                        if ($result && mysqli_num_rows($result) > 0) {
                                            while ($payment = mysqli_fetch_assoc($result)) {
                                                // Retrieve the payment details from the fetched row
                                                $firstname = $payment['firstname'];
                                                $lastname = $payment['lastname'];
                                                $amount = $payment['amount'];
                                                $txnid = $payment['txnid'];
                                                $pid = $payment['pid'];
                                                $payer_email = $payment['payer_email'];
                                                $currency = $payment['currency'];
                                                $mobile = $payment['mobile'];
                                                $address = $payment['address'];
                                                $note = $payment['note'];
                                                $payment_date = $payment['payment_date'];
                                                $status = $payment['status'];
                                
                                                // Continue with displaying or processing the retrieved data
                                                // For example, you can display the payment details in a table
                                                
                                                echo '<table class="table">
                                                    <tr>
                                                        <th>First Name</th>
                                                        <td>'.$firstname.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Last Name</th>
                                                        <td>'.$lastname.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Amount</th>
                                                        <td>'.$amount.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Transaction ID</th>
                                                        <td>'.$txnid.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Payment ID</th>
                                                        <td>'.$pid.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Email</th>
                                                        <td>'.$payer_email.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Currency</th>
                                                        <td>'.$currency.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Mobile</th>
                                                        <td>'.$mobile.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Address</th>
                                                        <td>'.$address.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Note</th>
                                                        <td>'.$note.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Payment Date</th>
                                                        <td>'.$payment_date.'</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Status</th>
                                                        <td>'.$status.'</td>
                                                    </tr>
                                                </table>';

                                                // You can also perform additional processing based on the retrieved data
                                                // For example, send an email notification, update other records, etc.
                                            }
                                        } else {
                                            $html = "<p><div class='errmsg'>Invalid Transaction. Please try again</div></p>";
                                            $error_found = 1;
                                            // Handle the appropriate logic here
                                        }
                                    } else {
                                        $html = "<p><div class='errmsg'>Invalid Transaction. Please try again</div></p>";
                                        $error_found = 1;
                                        // Error occurred while inserting the payment details
                                        // Handle the error appropriately
                                        echo "Error occurred while inserting the payment details: " . mysqli_error($con);
                                    }
                                } else {
                                    // Duplicate transaction, handle appropriately
                                    echo "Duplicate transaction";
                                }
                                
                            }
                            else
                            {
                                // Error occurred while checking the duplicate transaction
                                // Handle the error appropriately
                                echo "Error occurred while checking the duplicate transaction: " . mysqli_error($con);
                            }
                        }
                        else
                        {
                            // Payment ID not found, handle appropriately
                            echo "Payment ID not found";
                        }
                    }
                    else
                    {
                        // Payment verification failed, handle appropriately
                        echo $error;
                    }
                ?>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
